
# THIS FILE IS GENERATED FROM SCIPY SETUP.PY
short_version = '0.15.1'
version = '0.15.1'
full_version = '0.15.1'
git_revision = 'fcdc3d7b7c1b950d874ac3e890cccde3e2de1c6c'
release = True

if not release:
    version = full_version
